"""
A set of routines to convert between some standard formats 

"""
from __future__ import print_function, division
import os,sys
import numpy as np

__all__ = ['binary2netcdf']

def binary2netcdf(x,y,z,fname,dtype=None,ncform=4,title=None,name=None,scale=1.,
            offset=0,xunit=None,yunit=None,zunit=None,maxio=1.e8):
   """
   Write a headerless binary file to NetCDF format 

   Parameters
   ----------
   x      :     list, tuple, 2 element array of floats 
                [lower_left_longitude, longitude_spacing]
   y      :     list, tuple, 2 element array of floats 
                [lower_left_latitude, latitude_spacing]
   z      :     2d array 
                data to be written to netCDF file
   fname  :     string   
                output file name
   dtype  :     numpy data type
                output data type for z [same as z]
   ncform :     int (either 3 or 4) or str (netcdf4 type)
                NetCDF format [default=4]
   title  :     string or None
                title in NetCDF file [default=None]
   name   :     string or None
                name of NetCDF file [default=None]
   scale  :     float    
                scale_factor in NetCDF file [default=1.]
   offset :     int
                add_offset in NetCDF file [default=0]
   xunit  :     string or None
                units in x direction [default=None]
   yunit  :     string or None
                units in y direction [default=None]
   zunit  :     string or None 
                units in z direction [default=None]
   maxio  :     int or float
                maximum single block for output [1.e8]

   Output
   ------
   None

   Notes
   -----
   * if size(z) > maxio, file is written line by line to conserve memory. 

   """
   
   ncformoptions = ['NETCDF4', 'NETCDF4_CLASSIC','NETCDF3_CLASSIC','NETCDF3_64BIT']
   try:
      from netCDF4 import Dataset
   except:
      print("netCDF4 (a Python wrapper for NetCDF4) must be installed and in PYTHONPATH")
      raise
   try:
      a = len(x) 
      if len(x) != 2:
         print("x must be len 2.  Value passed = ",x)
         print(binary2netcdf.__doc__)
         return None
   except:
      print("x must be len 2.  Value passed = ",x)
      print(binary2netcdf.__doc__)
      return None
   try:
      a = len(y)
      if len(y) != 2:
         print("y must be len 2.  Value passed = ",y)
         print(binary2netcdf.__doc__)
         return None
   except:
      print("y must be len 2.  Value passed = ",y)
      print(binary2netcdf.__doc__)
      return None

   try:
      ncform = np.int32(ncform)
      if ncform == 4:
         ncformat = 'NETCDF4'
      elif ncform == 3:
         ncformat = 'NETCDF3_CLASSIC'
      else:
         print("ncform must be 3 or 4.  Defaulting to 4")
         ncformat = 'NETCDF4'
   except:
      if ncform not in ncformoptions:
         raise ValueError('%s ncform not recognized' % str(ncform))
      else:
         ncformat = ncform

   if xunit is None:  xunit = 'no unit'
   if yunit is None:  yunit = 'no unit'
   if zunit is None:  zunit = 'no unit'
   if name  is None:  name = 'no name'
   if title is None:  title = 'no title'

   if dtype is None:
      dtype = z.dtype
   elif dtype != z.dtype:
      print('converting z from %s to %s' % (str(z.dtype),str(dtype)))
      z = z.astype(dtype)

   fn = Dataset(fname,'w',format=ncformat)

   fn.createDimension('side',2)
   fn.createDimension('xysize',np.product(z.shape))

   fn.createVariable('x_range',np.float64,('side',))
   fn.variables['x_range'].units=xunit

   fn.createVariable('y_range',np.float64,('side',))
   fn.variables['y_range'].units=yunit

   fn.createVariable('z_range',np.float64,('side',))
   fn.variables['z_range'].units=zunit

   fn.createVariable('spacing',np.float64,('side',))
   fn.createVariable('dimension',np.int32,('side',))

   fn.createVariable('z',dtype,('xysize',))
   fn.variables['z'].long_name=name
   fn.variables['z'].scale_factor=scale
   fn.variables['z'].add_offset=offset
   fn.variables['z'].node_offset=0

   fn.title=title
   fn.source="created by PySAR binary2netcdf using netCDF4"

   # Fill the fields
   fn.variables['x_range'][0]=x[0]
   fn.variables['x_range'][1]=x[0] + x[1]*(z.shape[1]-1)
   fn.variables['spacing'][0]=x[1]

   fn.variables['y_range'][0]=y[0]
   fn.variables['y_range'][1]=y[0] + y[1]*(z.shape[0]-1)
   fn.variables['spacing'][1]=y[1]

   # determine zmin,zmax
   fn.variables['z_range'][0]=np.amin(z)
   fn.variables['z_range'][1]=np.amax(z)

   print("Writing array")
   nsp = np.asarray(z.shape)
   fn.variables['dimension'][:] = nsp[::-1]

   z = z.flatten()
   if len(z) > maxio:
      for i in np.arange(nsp[0]):
         fn.variables['z'][i*nsp[1]:(i+1)*nsp[1]] = z[i*nsp[1]:(i+1)*nsp[1]]
   else:
      fn.variables['z'][:]=z
   fn.close()
      
