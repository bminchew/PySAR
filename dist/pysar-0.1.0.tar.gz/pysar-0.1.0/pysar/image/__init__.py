'''
image
=====

Image module 

.. currentmodule:: pysar.image

Functions
---------

.. autosummary::
   :toctree: .
   :nosignatures:

   format_conversion    Convert between some common file formats
   looks                Decimate (look) 2D images
   poly2mask            Convert 2D polygon to mask

Scripts
-------

================     ======================================
`sarlooks`           2D image decimation
`sarfilter`          2D image filtering 
================     ======================================
'''
import numpy as np
from pysar.signal import boxfilter, conefilter

from poly2mask import *
from looks import *
try:
   from format_conversion import *
except:
   pass
import sarfilter
import sarlooks
