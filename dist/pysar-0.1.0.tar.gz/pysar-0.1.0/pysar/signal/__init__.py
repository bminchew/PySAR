"""
signal
======

1D and 2D signal processing routines

.. currentmodule:: pysar.signal

Functions
---------

.. autosummary::
   :toctree: .
   :nosignatures:

   boxfilter         1D and 2D boxcar filters
   butter            Butterworth filter
   conefilter        2D cone-shaped filter 

Scripts
-------

None
"""

import sys,os
import numpy as np

import boxfilter
import butter
 
__all__ = ['boxfilter','butter']
