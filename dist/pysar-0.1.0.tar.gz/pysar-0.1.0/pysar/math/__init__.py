'''
math
====

Math module

.. currentmodule:: pysar.math

Functions
---------

None

Scripts
-------

================     ======================================
`sarmath`             Basic math operations 
================     ======================================
'''
import sys,os
import numpy as np
