'''
plot
====

Really basic matplotlib add-ons 

.. currentmodule:: pysar.plot

Functions
---------

.. autosummary::
   :toctree: . 
   :nosignatures:

   cm       Additional colormaps from `http://soliton.vm.bytemark.co.uk/pub/cpt-city/`

Scripts
-------

None
'''
import cm
