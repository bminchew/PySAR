"""
Additional exceptions
"""

__all__ = ['InputError','InSARCorrBoundsError','cptError']

###===========================================================
class InputError(Exception):
   pass

###----------------------------------------
class InSARCorrBoundsError(Exception):
   pass

###----------------------------------------
class cptError(Exception):
   pass

###----------------------------------------
